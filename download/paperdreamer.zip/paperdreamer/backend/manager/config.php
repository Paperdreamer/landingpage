<?php
	define("USER_TABLE", "Users");
	define("ADMIN_TABLE", "Admins");
	define("SESSION_TABLE", "Session");
	define("PROJECT_TABLE", "Projects");
	define("USERSINPROJECTS_TABLE", "UsersInProjects");
	define("ASSET_TABLE", "Asset");
	define("ASSETTOCANVAS_TABLE", "Asset2Canvas");
	define("CANVAS_TABLE", "Canvas");
	define("TAG_TABLE", "Tag");
	define("TAGTOASSET_TABLE", "Tag2Asset");
	define("COMMENT_TABLE", "Comments");
?>
