<?php
	
	abstract class SystemPermission {
		// TODO: Implementation
	}
?>