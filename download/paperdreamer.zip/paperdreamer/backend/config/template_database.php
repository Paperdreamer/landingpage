<?php
	// Server config
	define("DBCharset", "utf8");
	define("DBHost", "%%HOST%%");
	define("DBPort", "%%PORT%%");

	// DB login config
	define("DBName", "%%NAME%%");
	define("DBUser", "%%USER%%");
	define("DBPassword", "%%PASSWORD%%");
?>